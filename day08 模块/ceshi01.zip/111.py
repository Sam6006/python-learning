def func():
	pass